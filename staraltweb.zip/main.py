#from memory_profiler import profile
from flask import render_template, Flask,send_file,request
from wtforms import Form, FloatField, validators,BooleanField,SelectField,TextAreaField,StringField,ValidationError
from io import BytesIO
import base64
import numpy as np
#from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib
import matplotlib.pyplot as plt
#import astropy
import astropy.time
import astropy.coordinates
import astropy.units as u
import astroplan
from astroquery.simbad import Simbad
from astropy.visualization import astropy_mpl_style
from matplotlib.lines import Line2D
#from pympler import muppy,summary
#import resource
#from memory_profiler import profile
#resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
#@app.route("/myplot", methods=["GET"])
matplotlib.use('Agg')

app = Flask(__name__)

import datetime

import base64

#@app.context_processor


class InputForm(Form):
    def check_obscode(form, field):
        obscode=np.genfromtxt("./static/ObsCode.txt",delimiter=(3,10,8,9,100),dtype="str",unpack=1,usecols=0)
        if field.data in ["245","247","249","250","258","270","275","C49","C50","C51","C52","C53","C54","C55","C56","C57","C59"]:
            raise ValidationError('Obscode must have defined lat and lon / be Earth-based')
        elif field.data not in obscode:
            raise ValidationError('Obscode must exist')
            del obscode
    def check_starttime(form, field):
        try:
            time=(astropy.time.Time(field.data,format="isot",scale="utc")).isot
            del time
        except:
            raise ValidationError('Please enter a real date')
    def check_target_list_length(form, field):
        splits=field.data.splitlines()
        if len(splits) > 7:
            raise ValidationError('Please list less than 6 targets (until I figure out memory limits)')
        elif len(splits) < 1:
            raise ValidationError('Please list at least 1 target')
        
        for split in splits:
            if len(split.strip()) == 0:
                raise ValidationError('Please remove empty lines from targets')
           # if split == "None":
              #  raise ValidationError('Please remove bogus lines from targets')
    
    lon = FloatField(label="Longitude (0<=lon<=360)", default=180.,validators=[validators.NumberRange(min=0,max=360,message="lon outside of bounds 0<=lon<=360")])
    lat = FloatField(label="Latitude (-90<=lat<=90)", default=45.,validators=[validators.NumberRange(min=-90,max=90,message="lat outside of bounds -90<=lat<=90")])
    mpccode = StringField(label="MPC Observatory code", default=309,validators=[check_obscode])
    usempc= BooleanField(label="Use MPC Observatory Code as location",default="")
    tnow = astropy.time.Time.now()
    starttime = StringField(label="Start time UT noon (YYYY-MM-DD)",default=tnow.isot.split("T")[0],validators=[validators.Regexp(regex="^[0-9]{4}-[0-9]{2}-[0-9]{2}$",message="starttime not in format YYYY-MM-DD"),check_starttime])
    targets = TextAreaField(label="List of target names to resolve (one name per line)",default="Vega",validators=[check_target_list_length])
    sortra= BooleanField(label="Sort by RA",default="")
    
#@profile    
@app.context_processor
def getplot(targets=["Vega"],starttime0="2020-10-15",lon=0,lat=0,height=2000,mpccode=str(309),usempc=False,sortra=False,trigger=False):
    img=BytesIO()
    plt.rcParams['svg.fonttype'] = 'none'
    if trigger == False:

        
        plt.figure()
        plt.style.use(astropy_mpl_style)
        plt.savefig(img,format="svg")
        
        plt.close()
        return img

    #color=["blue","red","green","purple","orange"]#,"magenta","purple"]
    color=['#377eb8', '#ff7f00', '#4daf4a','#f781bf', '#a65628']
    if usempc==False:
        location="User-defined {0:3.2f} {1:+3.2f} degrees".format(lon,lat)
        el=astropy.coordinates.EarthLocation(lon=lon * u.deg, lat=lat * u.deg, height=height * u.m)
    else:
        obscode,longitude,latitude_cos,latitude_sin,obsname=np.genfromtxt("./static/ObsCode.txt",delimiter=(3,10,8,9,100),dtype="str",unpack=1)
        sel=np.where(obscode == mpccode)[0]
        lon=np.float32(longitude[sel])
 #       del longitude
        latitude_sin=latitude_sin[sel][0]
#        del latitude_sin
        latitude_cos=latitude_cos[sel][0]
        #del latitude_cos
        obscode=obscode[sel][0]
        obsname=obsname[sel][0]
        lat=np.arctan2(np.float32(latitude_sin),np.float32(latitude_cos))/np.pi*180.
        el=astropy.coordinates.EarthLocation(lon=lon * u.deg, lat=lat * u.deg, height=height * u.m)
        location="Obs Code "+str(obscode)
        location=location+" - "+str(obsname.split("\n")[0])
        
    starttime0=starttime0+"T12:00:00"



        

        
    try:
        simb=Simbad.query_objects(targets)
        errmsg=None
        if (len(simb) != len(targets)):
            errmsg="Some targets do not resolve to valid Simbad objects"
            plt.savefig(img,format="svg")
            plt.close()
            del simb
            return img,errmsg
    except:
        errmsg="Some targets do not resolve to valid Simbad objects"
        plt.savefig(img,format="svg")
        plt.close()
        del simb
        return img,errmsg
    
    
    coords0=astropy.coordinates.SkyCoord(simb["RA"].data.data,simb["DEC"].data.data,unit=(u.hourangle,u.deg),frame="icrs")
    del simb
    
    
    
    
    targets0=targets.copy()
    if sortra == True:
        argra=np.argsort(simb["RA"].data.data)
        print(argra)
        coords=coords0[argra]
        targets=np.array(targets0)[argra].tolist()
    else:
        coords=coords0
        targets=targets0
    del coords0
    del targets0
    num_figs=np.int32(np.ceil(len(targets)/5.))
    fig,ax=plt.subplots(num_figs,figsize=(13,8*num_figs))
    plt.style.use(astropy_mpl_style)
    if num_figs==1:
        ax=[ax]
    for n in np.arange(num_figs):
        j=0
        starttime=(astropy.time.Time(starttime0,format="isot",scale="utc")+(j)*u.day).isot
        t = astropy.time.Time(starttime, format='isot', scale='utc')+np.linspace(0,24,200)*u.hour  # CET
        print(j,starttime,n)
        target=targets[0+5*n:5+5*n]
        coord=coords[0+5*n:5+5*n]
        altazsys=astropy.coordinates.AltAz(obstime=t,location=el)
        for i in np.arange(len(coord)):
            target_altaz = coord[i].transform_to(altazsys).alt.value
            ax[n].plot(np.linspace(0.,24.,200)*u.hour+12*u.hour,target_altaz,linewidth=3.,label=target[i]+"\n{0} {1}".format(coord[i].ra.to_string(u.hour,pad=True,precision=1),coord[i].dec.to_string(u.degree,pad=True,precision=1,alwayssign=True)),color=color[i],alpha=0.75)

        alt_sun = astropy.coordinates.get_sun(t).transform_to(altazsys).alt.value

        alt_moon = astropy.coordinates.get_moon(t).transform_to(altazsys).alt.value
        del altazsys
        ab=astroplan.moon.moon_illumination(t[0]+12*u.hour)
        ax[n].plot(np.linspace(0,24,200)*u.hour+12*u.hour,alt_sun,"--",color="y",label="Sun",linewidth=3.)
        ax[n].plot(np.linspace(0,24,200)*u.hour+12*u.hour,alt_moon,"--",color="grey",label="Moon"+" {0:3.1f}%".format(100.*ab),linewidth=3.)

        ax[n].set_ylim([0,90])
        ax[n].set_xlim([12,36])
        ax[n].set_title("start time: "+starttime+"\nlocation: "+location)

        ax[n].set_xlabel("Hours (UTC)")
        ax[n].set_ylabel("Altitude (degrees)")
        ax[n].set_xticks(np.arange(24)*1+12)
        a=ax[n].get_xticks().tolist()
        a=np.int32(a)%24
        diffalt=np.diff(alt_sun)
        handles, labels = ax[n].get_legend_handles_labels()
        if len(np.where(alt_sun<0)[0])>2: # sun sets long enough
            t_alt=np.linspace(0.,24.,200)+12.
            rising=np.where(diffalt>0)[0]
            setting=np.where(diffalt<0)[0]
            if len(rising)>2:
                t_rising=t_alt[rising]
                alt_rising=alt_sun[rising]
                x0=t_rising[np.argsort(np.abs(alt_rising-0))[0]]
                ax[n].plot([x0,x0],[0,90],"--",color="black") 
            if len(setting)>2:
                t_setting=t_alt[setting]
                alt_setting=alt_sun[setting]
                x1=t_setting[np.argsort(np.abs(alt_setting-0))[0]]
                ax[n].plot([x1,x1],[0,90],"--",color="black") 
            line_twi = Line2D([0], [0], label='Sunset/Sunrise', color='black',linestyle="--")
            
            handles.extend([line_twi])
        if len(np.where(alt_sun<-18)[0])>2: # sun in nighttime long enough
            t_alt=np.linspace(0,24,200)+12.
            rising=np.where(diffalt>0)[0]
            setting=np.where(diffalt<0)[0]
            if len(rising)>2:
                t_rising=t_alt[rising]
                alt_rising=alt_sun[rising]
                x2=t_rising[np.argsort(np.abs(alt_rising+18))[0]]
                ax[n].plot([x2,x2],[0,90],"--",color="gray") 
            if len(setting)>2:
                t_setting=t_alt[setting]
                alt_setting=alt_sun[setting]
                x3=t_setting[np.argsort(np.abs(alt_setting+18))[0]]
                ax[n].plot([x3,x3],[0,90],"--",color="gray")
            line_astrotwi = Line2D([0], [0], label='Astronomical twilight', color='gray',linestyle="--")
            handles.extend([line_astrotwi])
        ax[n].plot([24,24],[0,90],"-",color="black") # midnight line

        ax[n].set_xticklabels(a)
        box=ax[n].get_position()
        ax[n].set_position([box.x0, box.y0, box.width * 0.7, box.height])
        
        secax = ax[n].twinx()
        plt.style.use(astropy_mpl_style)
        secax.set_position([box.x0, box.y0, box.width * 0.7, box.height])
        secax.grid(visible=False)
        
        #alt = 90-np.arccos(1./airmass)/np.pi*180.
        secax.set_yticks(
        [19.47122063449069,30.,36.03187907247056,41.81031489577859,50.28486276817378,56.442690238079294,65.38002267134289,90.],
        labels=[3.0,2.0,1.7,1.5,1.3,1.2,1.1,1.0])
        secax.tick_params(direction='out', length=6, width=2, colors='grey',grid_alpha=0.5)
        
        secax.set_ylabel("Airmass")
        
        ax[n].legend(handles=handles,bbox_to_anchor=(1.09, 0.0), loc='lower left')
        

    fig.savefig(img,format="svg")
    #fig.savefig(img_pdf,format="pdf")
    plt.close()
#    img.seek(0)
 #   plot_url = base64.b64encode(img.getvalue()).decode('utf8')

    return img,errmsg


#@profile
@app.route('/',methods=['GET','POST'])
def plot():
    if True:
    #try:

        form=InputForm(request.form)
        if request.method == 'POST' and form.validate():
            
        
            img,errmsg=getplot(starttime0=str(form.starttime.data),lon=form.lon.data,lat=form.lat.data,targets=form.targets.data.splitlines(),mpccode=form.mpccode.data,usempc=form.usempc.data,sortra=form.sortra.data,trigger=True)
        
            img.seek(0)
        
            plot_url = base64.b64encode(img.getvalue()).decode('utf8')
   #         allObjects = muppy.get_objects()
  #          sum = summary.summarize(allObjects)
 #           print(summary.print_(sum))
#            print(resource.getrusage(resource.RUSAGE_SELF))
            return render_template('plot.html', plot_url=plot_url,form=form,errmsg=errmsg)
        else:
            plot_url=None
            errmsg=None
            return render_template('plot.html', plot_url=plot_url,form=form,errmsg=errmsg)
    #except:
     #   return render_template('err.html')

if __name__ == '__main__':
    # This is used when running locally only. When deploying to Google App
    # Engine, a webserver process such as Gunicorn will serve the app. You
    # can configure startup instructions by adding `entrypoint` to app.yaml.
    app.run(host='127.0.0.1', port=8080, debug=True)


